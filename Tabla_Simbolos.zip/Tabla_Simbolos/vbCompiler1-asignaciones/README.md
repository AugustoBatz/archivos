vbCompiler1
===========

Very Basic Compiler for students.
