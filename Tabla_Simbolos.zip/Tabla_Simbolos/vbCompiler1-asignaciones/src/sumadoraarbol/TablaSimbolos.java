/*
 * Copyright (C) 2018 sys515
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sumadoraarbol;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author sys515
 */
public class TablaSimbolos {
 Conector cosn = new Conector();
   private String id;
   private String valor;
   private String idFuncion;
    
  
        
    
   public void save(){
        Conector con = new Conector();
        con.connect();
        con.insert(this);
        con.close();
    }
    public void Borrar()
    {
        Conector con=new Conector();
        con.connect();
        con.borrar();
        con.close();
    }
    public Boolean comparar()
    {
        Conector con=new Conector();
        con.connect();
        Boolean a =con.comparar(this);
        con.close();
        return a;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(String idFuncion) {
        this.idFuncion = idFuncion;
    }

    
}
