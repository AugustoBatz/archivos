/*
 * Copyright (C) 2018 sys515
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package sumadoraarbol;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sys515
 */
public class Conector {

    String url =System.getProperty("user.dir")+"/tablasimbolos.db";
    
    Connection connect;
    /**
     * @param args the command line arguments
     */
  
    public void connect(){
       
 try {
     connect = DriverManager.getConnection("jdbc:sqlite:"+url);
     if (connect!=null) {
         System.out.println("Conectado");
     }
 }catch (SQLException ex) {
     System.err.println("No se ha podido conectar a la base de datos\n"+ex.getMessage());
 }
}
 public void close(){
        try {
            connect.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conector.class.getName()).log(Level.SEVERE, null, ex);
        }
 }
 public void borrar()
 {
     
          
        try {
            PreparedStatement ActualizarProveedor = connect.prepareStatement("Delete from simbolos");
            ActualizarProveedor.executeUpdate();
            connect.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conector.class.getName()).log(Level.SEVERE, null, ex);
        }
 
 }
 public Boolean comparar(TablaSimbolos a)
 {
     Boolean num=false;
     ResultSet result = null;
        try {
            PreparedStatement st = connect.prepareStatement("select * from simbolos where id='"+a.getId()+"'");
            result = st.executeQuery();
            while (result.next()) {
               num=true;
            }
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
        return num;
 }
 public void insert(TablaSimbolos a)
   {
    
           try {
            PreparedStatement st = connect.prepareStatement("insert into simbolos (id ) values (?)");
            st.setString(1, a.getId());
   
            st.execute();
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
       
      
        
        
   }
 
    PreparedStatement prepareStatement(String insert_into_alumnos_nombre_apellidos_valu) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
